import json
from flask import Flask, url_for, request

app = Flask(__name__)

@app.route('/')
def start():
    return """<!doctype html>
                <html lang="en">
                  <head>
                    <meta charset="utf-8">
                    <p><a href="/enter">Войти</a>
                  </head>
                  <body>
                    <p><a href="/form_sample">Зарегистрироваться</a>
                  </body>
                </html>"""

@app.route('/enter', methods=['POST', 'GET'])
def enter():
    global name1
    if request.method == 'GET':
        return f'''<!doctype html>
                        <html lang="en">
                          <head>
                            <meta charset="utf-8">
                            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                            <link rel="stylesheet"
                            href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
                            integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1"
                            crossorigin="anonymous">
                            <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}" />
                            <title>Пример формы</title>
                          </head>
                          <body>
                            <h1>Форма для регистрации в суперсекретной системе</h1>
                            <div>
                                <form class="login_form" method="post">
                                    <input type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Введите адрес почты" name="email">
                                    <input type="password" class="form-control" id="password" placeholder="Введите пароль" name="password">
                                     </div>
                                    <button type="submit" class="btn btn-primary">Войти</button>
                                </form>
                            </div>
                          </body>
                        </html>'''
    elif request.method == 'POST':
        with open('baza.json') as f:
            f = json.load(f)
            print(f)
            print(type(f))
            name1 = request.form['email']
            for i in f:
                if i['name'] == request.form['email']:
                    if i['password'] == request.form['password']:
                        return f'''<!doctype html>
                                                <html lang="en">
                                                  <head>
                                                    <meta charset="utf-8">
                                                    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                                                    <link rel="stylesheet"
                                                    href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
                                                    integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1"
                                                    crossorigin="anonymous">
                                                    <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}" />
                                                    <title>Пример формы</title>
                                                  </head>
                                                  <body>
                                                   <img src="{url_for('static', filename='img/img_1.png')}"
           alt="здесь должна была быть картинка, но не нашлась">
                                                    <h1>Привет, {request.form['email']}</h1>
                                                    <div>
                                                    <h1> Твой класс: {i['class']}</h1>
                                                    <h1>Информация о тебе: {i['about']}</h1>
                                                    <h1>Твой пол: {i['sex']}</h1>
                                                    <p><a href="/refactor">Изменить</a>
                                                    <p><a href="/">Вернуться на главную</a>
                                                  <body>
                                                </html>'''


@app.route('/refactor', methods=['POST', 'GET'])
def form_sample():
    if request.method == 'GET':
        return f'''<!doctype html>
                        <html lang="en">
                          <head>
                            <meta charset="utf-8">
                            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                            <link rel="stylesheet"
                            href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
                            integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1"
                            crossorigin="anonymous">
                            <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}" />
                            <title>Пример формы</title>
                          </head>
                          <body>
                            <h1>Форма для регистрации в суперсекретной системе</h1>
                            <div>
                                <form class="login_form" method="post">
                                    <input type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Введите адрес почты" name="email">
                                    <input type="password" class="form-control" id="password" placeholder="Введите пароль" name="password">
                                    <div class="form-group">
                                        <label for="classSelect">В каком вы классе</label>
                                        <select class="form-control" id="classSelect" name="class">
                                          <option>7</option>
                                          <option>8</option>
                                          <option>9</option>
                                          <option>10</option>
                                          <option>11</option>
                                        </select>
                                     </div>
                                    <div class="form-group">
                                        <label for="about">Немного о себе</label>
                                        <textarea class="form-control" id="about" rows="3" name="about"></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="photo">Приложите фотографию</label>
                                        <input type="file" class="form-control-file" id="photo" name="file">
                                    </div>
                                    <div class="form-group">
                                        <label for="form-check">Укажите пол</label>
                                        <div class="form-check">
                                          <input class="form-check-input" type="radio" name="sex" id="male" value="male" checked>
                                          <label class="form-check-label" for="male">
                                            Мужской
                                          </label>
                                        </div>
                                        <div class="form-check">
                                          <input class="form-check-input" type="radio" name="sex" id="female" value="female">
                                          <label class="form-check-label" for="female">
                                            Женский
                                          </label>
                                        </div>
                                    </div>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Изменить</button>
                                </form>
                            </div>
                          </body>
                        </html>'''
    elif request.method == 'POST':
        name = request.form['email']
        pas = request.form['password']
        if request.form['email'] == '' or request.form['password'] == '':
            return 'Форма не отправлена. Введите логин и пароль'
        with open('baza.json') as f:
            f = json.load(f)
            for i in f:
                if i['name'] == name1:
                    f.remove(i)
            f.append({'name': name,
                      'password': pas,
                      'class': request.form['class'],
                      'file': request.form['file'],
                      'about': request.form['about'],
                      'sex': request.form['sex']})
        with open('baza.json', 'w') as f1:
            json.dump(f, f1, indent=2)
        return f'''<!doctype html>
                                                <html lang="en">
                                                  <head>
                                                    <meta charset="utf-8">
                                                    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                                                    <link rel="stylesheet"
                                                    href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
                                                    integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1"
                                                    crossorigin="anonymous">
                                                    <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}" />
                                                    <title>Пример формы</title>
                                                  </head>
                                                  <body>
                                                   <img src="{url_for('static', filename='img/img_1.png')}"
           alt="здесь должна была быть картинка, но не нашлась">
                                                    <h1>Привет, {request.form['email']}</h1>
                                                    <div>
                                                    <h1> Твой класс: {request.form['class']}</h1>
                                                    <h1>Информация о тебе: {request.form['about']}</h1>
                                                    <h1>Твой пол: {request.form['sex']}</h1>
                                                    <p><a href="/refactor">Изменить</a>
                                                    <p><a href="/">Вернуться на главную</a>
                                                  <body>
                                                </html>'''



@app.route('/form_sample', methods=['POST', 'GET'])
def form():
    global name1
    if request.method == 'GET':
        return f'''<!doctype html>
                        <html lang="en">
                          <head>
                            <meta charset="utf-8">
                            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                            <link rel="stylesheet"
                            href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
                            integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1"
                            crossorigin="anonymous">
                            <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}" />
                            <title>Пример формы</title>
                          </head>
                          <body>
                            <h1>Форма для регистрации в суперсекретной системе</h1>
                            <div>
                                <form class="login_form" method="post">
                                    <input type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Введите адрес почты" name="email">
                                    <input type="password" class="form-control" id="password" placeholder="Введите пароль" name="password">
                                    <div class="form-group">
                                        <label for="classSelect">В каком вы классе</label>
                                        <select class="form-control" id="classSelect" name="class">
                                          <option>7</option>
                                          <option>8</option>
                                          <option>9</option>
                                          <option>10</option>
                                          <option>11</option>
                                        </select>
                                     </div>
                                    <div class="form-group">
                                        <label for="about">Немного о себе</label>
                                        <textarea class="form-control" id="about" rows="3" name="about"></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="photo">Приложите фотографию</label>
                                        <input type="file" class="form-control-file" id="photo" name="file">
                                    </div>
                                    <div class="form-group">
                                        <label for="form-check">Укажите пол</label>
                                        <div class="form-check">
                                          <input class="form-check-input" type="radio" name="sex" id="male" value="male" checked>
                                          <label class="form-check-label" for="male">
                                            Мужской
                                          </label>
                                        </div>
                                        <div class="form-check">
                                          <input class="form-check-input" type="radio" name="sex" id="female" value="female">
                                          <label class="form-check-label" for="female">
                                            Женский
                                          </label>
                                        </div>
                                    </div>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Записаться</button>
                                </form>
                            </div>
                          </body>
                        </html>'''
    elif request.method == 'POST':
        name = request.form['email']
        name1 = request.form['email']
        pas = request.form['password']
        if request.form['email'] == '' or request.form['password'] == '':
            return 'Форма не отправлена. Введите логин и пароль'
        with open('baza.json') as f:
            f = json.load(f)
            for i in f:
                if i['name'] == name:
                    return 'Таокй пользователей уже зарегистрирован'
            f.append({'name': name,
                      'password': pas,
                      'class': request.form['class'],
                      'file': request.form['file'],
                      'about': request.form['about'],
                      'sex': request.form['sex']})
        with open('baza.json', 'w') as f1:
            json.dump(f, f1, indent=2)
        return f'''<!doctype html>
                                                <html lang="en">
                                                  <head>
                                                    <meta charset="utf-8">
                                                    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                                                    <link rel="stylesheet"
                                                    href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
                                                    integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1"
                                                    crossorigin="anonymous">
                                                    <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}" />
                                                    <title>Пример формы</title>
                                                  </head>
                                                  <body>
                                                   <img src="{url_for('static', filename='img/img_1.png')}"
           alt="здесь должна была быть картинка, но не нашлась">
                                                    <h1>Привет, {request.form['email']}</h1>
                                                    <div>
                                                    <h1> Твой класс: {i['class']}</h1>
                                                    <h1>Информация о тебе: {i['about']}</h1>
                                                    <h1>Твой пол: {i['sex']}</h1>
                                                    <p><a href="/refactor">Изменить</a>
                                                  <body>
                                                </html>'''


if __name__ == '__main__':
    from waitress import serve

    serve(app, host="127.0.0.1", port=8080)
